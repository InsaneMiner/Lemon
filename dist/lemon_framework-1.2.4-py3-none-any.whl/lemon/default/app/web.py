import lemon.libs.lemon
def main(object):
    return lemon.libs.lemon.Render(object,"default.html")