import lemon.StartDevServer as DevServer
if __name__ == "__main__":
    DevServer.Start()