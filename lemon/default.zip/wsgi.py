import lemon.wsgi as wsgi



# Function is located in lemon.wsgi

application = wsgi.application

