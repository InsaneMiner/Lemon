import lemon.libs.lemon
def main(object):
    return lemon.libs.lemon.render_template(object,"default.html")